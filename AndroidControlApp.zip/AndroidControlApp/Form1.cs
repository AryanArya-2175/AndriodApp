using System;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using Newtonsoft.Json; 

namespace AndroidControlApp
{
    public partial class Form1 : Form
    {
        string connectionString = @"Data Source=localhost;Initial Catalog=AndroidDataLocker;Integrated Security=True;";
        private readonly System.Windows.Forms.Timer _timer;

        public Form1()
        {
            InitializeComponent();
            _timer = new System.Windows.Forms.Timer { Interval = 5000 };
            _timer.Tick += (s, e) =>
            {
                _timer.Stop();
                this.Hide();
                new Form2().Show();
            };
        }

        private void SaveToDatabase(string deviceName, string extractedData)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO DeviceData (DeviceName, ExtractedData, ExtractedOn) VALUES (@DeviceName, @ExtractedData, @ExtractedOn)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@DeviceName", deviceName);
                cmd.Parameters.AddWithValue("@ExtractedData", extractedData);
                cmd.Parameters.AddWithValue("@ExtractedOn", DateTime.Now);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("Data saved to database.");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // No timer start here anymore
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtDeviceName.Text) || string.IsNullOrWhiteSpace(txtExtractedData.Text))
            {
                MessageBox.Show("Please enter both Device Name and Extracted Data.");
                return;
            }

            SaveToDatabase(txtDeviceName.Text, txtExtractedData.Text);
            _timer.Start(); // <-- Start the timer after saving
        }

    }
}