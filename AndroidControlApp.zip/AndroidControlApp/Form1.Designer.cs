﻿namespace AndroidControlApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private Label labelWelcome;
        private Button btnSave;
        private TextBox txtDeviceName;
        private TextBox txtExtractedData;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            labelWelcome = new Label();
            btnSave = new Button();
            txtDeviceName = new TextBox();
            txtExtractedData = new TextBox();
            SuspendLayout();

            // labelWelcome
            labelWelcome.AutoSize = true;
            labelWelcome.Location = new Point(207, 74);
            labelWelcome.Name = "labelWelcome";
            labelWelcome.Size = new Size(196, 20);
            labelWelcome.Text = "WELCOME TO MY ANDROID";

            // btnSave
            btnSave.Location = new Point(269, 250);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(94, 29);
            btnSave.TabIndex = 1;
            btnSave.Text = "Save";
            btnSave.Click += btnSave_Click;

            // txtDeviceName
            txtDeviceName.Location = new Point(200, 120);
            txtDeviceName.Name = "txtDeviceName";
            txtDeviceName.PlaceholderText = "Device Name";
            txtDeviceName.Size = new Size(250, 27);

            // txtExtractedData
            txtExtractedData.Location = new Point(200, 180);
            txtExtractedData.Multiline = true;
            txtExtractedData.Name = "txtExtractedData";
            txtExtractedData.PlaceholderText = "Extracted Data";
            txtExtractedData.Size = new Size(250, 50);

            // Form1
            BackColor = Color.Honeydew;
            ClientSize = new Size(682, 400);
            Controls.Add(txtExtractedData);
            Controls.Add(txtDeviceName);
            Controls.Add(btnSave);
            Controls.Add(labelWelcome);
            Name = "Form1";
            Text = "Android Data Manager";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }
    }
}